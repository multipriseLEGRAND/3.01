import os

from django.apps import AppConfig

class PrisesConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'prises'

    def ready(self):
        from .tache_horaire import start_scheduler
        start_scheduler()
        import threading
        from . import mqtt_listener

        thread = threading.Thread(target=mqtt_listener.start_listener, daemon=True)
        thread.start()
        print("[MQTT] mqtt_listener démarré depuis ready()")


# --- RBAC groups bootstrap ---
from django.contrib.auth.models import Group

def _ensure_groups():
    Group.objects.get_or_create(name="controle_leds")
    Group.objects.get_or_create(name="temperature_viewer")

# Ensure groups on app ready
try:
    _ensure_groups()
except Exception as e:
    # During migrations, DB might not be ready; ignore then.
    print("[RBAC] Group setup skipped:", e)
