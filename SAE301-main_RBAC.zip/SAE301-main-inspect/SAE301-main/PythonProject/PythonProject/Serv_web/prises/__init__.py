default_app_config = 'prises.apps.PrisesConfig'
