from apscheduler.schedulers.background import BackgroundScheduler
from datetime import datetime, time
from .models import Prise
from .mqtt_client import envoyer_commande_prise

def is_now_in_range(now: time, start: time, end: time) -> bool:
    """Retourne True si 'now' est dans l'intervalle [start, end] (gère les plages qui traversent minuit)."""
    if start and end:
        if start <= end:
            return start <= now <= end
        else:
            return now >= start or now <= end
    return False

def verifier_plages():
    """Vérifie périodiquement les prises avec horaire_active et publie les commandes nécessaires."""
    now = datetime.now().time()
    for prise in Prise.objects.filter(horaire_active=True):
        if not prise.heure_on or not prise.heure_off:
            continue
        should_be_on = is_now_in_range(now, prise.heure_on, prise.heure_off)
        if should_be_on and not prise.etat:
            envoyer_commande_prise(prise.id, "on")
            prise.etat = True
            prise.save(update_fields=["etat"])
        elif (not should_be_on) and prise.etat:
            envoyer_commande_prise(prise.id, "off")
            prise.etat = False
            prise.save(update_fields=["etat"])

_scheduler = None

def start_scheduler():
    global _scheduler
    if _scheduler is None:
        _scheduler = BackgroundScheduler()
        _scheduler.add_job(verifier_plages, 'interval', seconds=10)
        _scheduler.start()
