import os
from django.apps import AppConfig

from django.conf import settings

class PrisesConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'prises'

    def ready(self):
        # Lancer le scheduler et le listener MQTT (comportement existant)
        try:
            from .tache_horaire import start_scheduler
            if getattr(settings, 'START_BACKGROUND_WORKERS', False):
                start_scheduler()
        except Exception as e:
            print("[SCHED] Ignored scheduler start:", e)

        try:
            import threading
            from . import mqtt_listener
            if getattr(settings, 'START_BACKGROUND_WORKERS', False):
                thread = threading.Thread(target=mqtt_listener.start_listener, daemon=True)
                thread.start()
                print("[MQTT] mqtt_listener démarré depuis ready()")
        except Exception as e:
            print("[MQTT] Ignored listener start:", e)

        # Créer les groupes RBAC si besoin (une fois la DB prête)
        try:
            from django.contrib.auth.models import Group
            Group.objects.get_or_create(name="controle_leds")
            Group.objects.get_or_create(name="temperature_viewer")
        except Exception as e:
            print("[RBAC] Group setup skipped:", e)

# Pour la prod multi-workers, activer les workers via variable START_BACKGROUND_WORKERS=True dans settings ou env.
